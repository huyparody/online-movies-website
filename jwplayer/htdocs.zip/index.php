<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"content="width=device-width, initial-scale=1"/>
	<title>System Get-Link Drive</title>
	<meta name="keywords"content=""/>
	<meta name="description"content=""/>
	<link href="//cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap.min.css"rel="stylesheet"/>
	<script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
	<script src="//cdn.bootcss.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<link rel="shortcut icon"href="favicon.ico"/>
	<link rel="bookmark"href="favicon.ico"/>

	<script type="text/javascript">eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('b a(){0 6=1.2("9").4;0 5=1.2("3");0 3=1.2("3").c;0 8=5.e[3].4;0 7=1.2("f");7.d=8+6}',16,16,'var|document|getElementById|jk|value|jkurl|diz|cljurl|jkv|url|dihejk|function|selectedIndex|src|options|player'.split('|'),0,{}))
	</script>
</head>
<body>
</br>
	<div class="container"style="padding-top:0px;"id="wbk">
			<div class="alert alert-success alert-dismissible"role="alert">
				<button type="button"class="close"data-dismiss="alert">
					<span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
				</button>
					<strong>
						<center>Hệ Thống Get-Link Drive<a href="http://www.anivn.com/" target="_blank">, Được Cấp Bởi Võ Phước Tiến</a></center>
					</strong>
			</div>
		<div class="col-md-14 column">
			<div class="panel panel-default">
				<div id="kj"class="panel-body">
					<section class="film-wrapper not-slider">
						<div class="film-container">
							<div class="player-view">
								<div class="player-view-video">
<?php
error_reporting(0);
function viewsource($url){
    $ch      = curl_init();
    $timeout = 15;
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.69 Safari/537.36");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}

function GetLinkAPI($curl){ // Dành cho VideoJS
    $get = viewsource('https://api.anivn.com/?url=' . $curl);
    $remove = str_replace('\/','/',$get);
    preg_match_all('#"(.+?)":"(.+?)"#',$remove,$data);
	preg_match_all('#<title>(.+?)</title>#',viewsource($curl),$title);
	$tieude = str_replace('.MP4 - Google Drive','',$title[1][0]);
	$tieude = str_replace('.mp4 - Google Drive','',$title[1][0]);
	$tieude = str_replace('.Mp4 - Google Drive','',$title[1][0]);
	foreach ($data[2] as $i => $quality) {
		if (strpos($data[1][$i], '360') !== false) {
            $video = '<video id="videoPlayer" src="'.$data[2][$i].'&amp;title=[VEDJSC.Com]-'.$tieude.'-(360p)" controls playsinline preload="auto" video_id="318" class="vg-video vgplayer-skin iplayer-skin" width="100%" height="600px">';
        } if (strpos($data[1][$i], '1080') !== false) {
            $v1080p = '<source src="'.$data[2][$i].'&amp;title=[VEDJSC.Com]-'.$tieude.'-(1080p)"  quality="1080p" type="video/Mp4">';
        } elseif (strpos($data[1][$i], '720') !== false) {
            $v720p = '<source src="'.$data[2][$i].'&amp;title=[VEDJSC.Com]-'.$tieude.'-(720p)"  quality="720p" type="video/Mp4">';
        } elseif (strpos($data[1][$i], '480') !== false) {
            $v480p = '<source src="'.$data[2][$i].'&amp;title=[VEDJSC.Com]-'.$tieude.'-(480p)" default=true quality="480p" type="video/Mp4">';
        } elseif (strpos($data[1][$i], '360') !== false) {
            $v360p = '<source src="'.$data[2][$i].'&amp;title=[VEDJSC.Com]-'.$tieude.'-(360p)"  quality="360p" type="video/Mp4">';
        }
    }
    return $video.$v1080p.$v720p.$v480p.$v360p;
}
?>
<?php echo GetLinkAPI ('https://drive.google.com/open?id=0B70Iv8AX9TmuaERZbG1UaWRGU0U'); ?>
	</video>
								</div>
							</div>
						</div>
					</section>
				</div>
	<link rel="stylesheet" href="/jwplayer/player.min-284b8de7f5.css">
	<script type="text/javascript" src="/jwplayer/jquery.min-cd0095b52c.js"></script>
	<script type="text/javascript" src="/jwplayer/vue.min-fc512ede9a.js"></script>
	<script type="text/javascript" src="/jwplayer/store.min-b3dba894be.js"></script>
	<script type="text/javascript" src="/jwplayer/ismobile.min-1b30678ec9.js"></script>
	<script type="text/javascript" src="/jwplayer/player.min-0df67eac1c.js"></script>
	<script type="text/javascript" src="/jwplayer/film-09a0d155cb.js"></script>
			</div>
		</div>

		<div class="col-md-14 column">
	<form method="get"><div class="input-group"style="width: 100%;">
		<span class="input-group-addon input-lg"style="width: 80px; ">Máy Chủ Get</span>
		<select class="form-control input-lg"id="jk">
			<option value="//api.anivn.com?url="selected>AniVN</option>
			<option value="//api.locphim.com?url=">Lọc Phim</option>
		</select>
		</div>
		<br/>
		<div class="input-group"style="width: 100%;">
		<span class="input-group-addon input-lg"style="width: 80px;">Link Drive</span>
		<input class="form-control input-lg" type="search" placeholder="Nhập Link Cần Get" id="url"/>
		</div>
	<br>
		<div>
			<button id="bf"type="button"class="btn btn-success btn-lg btn-block"onclick="dihejk()">Xem Video</button>
		</div>
	</form>
</div>
		
	</br>
		<div class="alert alert-danger"role="alert">
			<center><a href="#" target="_blank"><strong>Yêu Cầu Phải Là Link Drive</strong></a></center>
		</div>
	</div>
</body>
</html>
